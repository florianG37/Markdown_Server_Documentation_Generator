import setuptools


with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setuptools.setup(
    name='Markdown_Server_Documentation_Generator',
    version='0.1.5',
    packages=setuptools.find_packages(),
    package_data={
        "": ["*.pmd"],
    },
    url='https://github.com/florianG37/Markdown_Server_Documentation_Generator',
    license='MIT',
    author='Florian GIGOT',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='~=3.6',
    install_requires=requirements,
    entry_points={'console_scripts': ['mrgenerator-cli = mrgenerator.run:cli']}
)